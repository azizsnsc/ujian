###################
MISS | Management Information School System
###################

MISS adalah sebuah sistem infromasi yang dikembangkan menggunakan codeigniter dan bertujuan
untuk memudahkan management informasi di dalam sekolahan.